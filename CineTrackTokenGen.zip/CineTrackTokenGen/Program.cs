using Microsoft.Azure.Relay;

// =====================================================
// CONFIGURAÇÃO DO CINETRACK RELAY
// =====================================================
var keyName = "ListenSend";
var key = "utF7HeUUp88IDZdYUtbsQ6nDZnbNOh2jU+ARmEAh9lo=";
var uri = "https://cinetrack-relay.servicebus.windows.net/cinetrack-bridge";
// =====================================================

var tokenProvider = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, key);

var token = await tokenProvider.GetTokenAsync(uri, TimeSpan.FromDays(365 * 50));

Console.WriteLine("========================================");
Console.WriteLine("  CineTrack - TOKEN DE 50 ANOS");
Console.WriteLine("========================================");
Console.WriteLine();
Console.WriteLine("TOKEN:");
Console.WriteLine(token.TokenString);
Console.WriteLine();
Console.WriteLine($"Expira em: {token.ExpiresAtUtc:dd/MM/yyyy HH:mm:ss}");
Console.WriteLine();
Console.WriteLine("========================================");
Console.WriteLine("Use este token no header:");
Console.WriteLine("ServiceBusAuthorization: <TOKEN>");
Console.WriteLine("========================================");
